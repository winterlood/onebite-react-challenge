import "./ContactItem.css";

export default function ContactItem() {
  return (
    <div className="ContactItem">
      <div className="name">이정환</div>
      <div className="contact">king199777@gmail.com</div>
      <button>🗑️ Remove</button>
    </div>
  );
}
